
#pragma once

#ifdef __cplusplus
extern "C" {
#endif /**< _cplusplus */

void adc_cheak(void);

#ifdef __cplusplus
}
#endif /**< _cplusplus */