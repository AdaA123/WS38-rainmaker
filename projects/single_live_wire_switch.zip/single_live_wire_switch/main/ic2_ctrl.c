#include <string.h>
#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/semphr.h"
#include "esp_log.h"
#include "driver/adc.h"

#include "ic2_ctrl.h"
#include "bri_ctrl.h"

#define TIMES 256

#define GET_ADC_TIMES 100 //次数

#define GET_ADC_DEALY 2*60 //s

static void single_read(void* arg)
{
    uint32_t adc1_reading_sum = 0;
    uint16_t adc1_reading;
    int n, ic2_cnt = 0;

    adc1_config_width(ADC_WIDTH_BIT_DEFAULT);
    adc1_config_channel_atten(ADC1_CHANNEL_3, ADC_ATTEN_DB_11);

    vTaskDelay(pdMS_TO_TICKS(5 * 1000));

    do {
        n = GET_ADC_TIMES;

        while (n--) 
        {
            adc1_reading_sum += adc1_get_raw(ADC1_CHANNEL_3);
        }

        adc1_reading = adc1_reading_sum / GET_ADC_TIMES;
        //ESP_LOGI("single_read ADC1_CH3", "%d", adc1_reading);
        adc1_reading_sum = 0;

        if (2284 > adc1_reading) // 1.45v (0~2.6v)
        {
            if (3 < ic2_cnt)
            {
                //send_bri_ctrl_info(CChargingCMD, 1);
                //esp_wifi_stop();
            }
            else 
            {
                ic2_cnt++;
            }
        }
        else if (2284 < adc1_reading && 0 < ic2_cnt)
        {
            ic2_cnt--;
            if (0 == ic2_cnt)
            {
                send_bri_ctrl_info(CChargingCMD, 0);
                //esp_wifi_start();
            }
        }

        vTaskDelay(pdMS_TO_TICKS(GET_ADC_DEALY * 1000));
    } while (1);

    vTaskDelete(NULL);
}

void adc_cheak(void)
{
    xTaskCreate(single_read, "single_read_adc_task", 2*1024, NULL, 5, NULL);
}

