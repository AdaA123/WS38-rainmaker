- [中文版本](README_CN.md)
## Single Live Wire Switch Example

This project is the single live wire smart swith demo based on [RainMaker](https://rainmaker.espressif.com/). And the example based on Qcloud is on the master branch.

Please use  ` git checkout master ` to try the Qcloud example.
