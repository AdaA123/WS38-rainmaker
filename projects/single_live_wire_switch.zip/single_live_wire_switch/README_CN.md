- [English Version](./README.md)
## Single Live Wire Switch Example


这是基于 [RainMaker](https://rainmaker.espressif.com/) 开发的单火线项目，基于 Qcloud 开发的项目在 master 分支上。

可以通过  ` git checkout master ` 指令来进行切换查看。
